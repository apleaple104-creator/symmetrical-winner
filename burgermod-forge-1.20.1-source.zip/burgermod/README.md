# Burger Mod (Forge 1.20.1)

Isi: 10 item (Roti Burger, Patty, 7 jenis burger dengan efek, Buku Resep) + tab kreatif.
Resep ada di data/burgermod/recipes, dan Buku Resep (klik kanan) menampilkannya di dalam game.

## Build lewat GitHub (bisa dari HP)
1. Buat repo baru di GitHub, upload semua isi folder ini (termasuk folder .github).
2. Buka tab Actions -> "Build mod" -> Run workflow.
3. Selesai (sekitar 5-10 menit), unduh artifact "burgermod-jar", ekstrak, ambil file .jar.
4. Taruh .jar di folder mods Minecraft Forge 1.20.1 (Forge 47.2.0 atau lebih baru).

## Build di PC
Perlu JDK 17 dan Gradle 8.1.1: jalankan `gradle build`, hasil di build/libs/.
