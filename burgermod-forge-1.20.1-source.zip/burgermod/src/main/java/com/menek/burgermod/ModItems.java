package com.menek.burgermod;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, BurgerMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, BurgerMod.MODID);

    // Bahan
    public static final RegistryObject<Item> ROTI_BURGER = ITEMS.register("roti_burger",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(3).saturationMod(0.4F).build())));
    public static final RegistryObject<Item> PATTY = ITEMS.register("patty",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(4).saturationMod(0.6F).meat().build())));

    // Burger
    public static final RegistryObject<Item> BURGER_BIASA = ITEMS.register("burger_biasa",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).build())));

    public static final RegistryObject<Item> BURGER_API = ITEMS.register("burger_api",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 20 * 180, 0), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 30, 0), 1.0F)
                            .build())));

    public static final RegistryObject<Item> BURGER_KECEPATAN = ITEMS.register("burger_kecepatan",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 90, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.JUMP, 20 * 90, 1), 1.0F)
                            .build())));

    public static final RegistryObject<Item> BURGER_MALAM = ITEMS.register("burger_malam",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.NIGHT_VISION, 20 * 300, 0), 1.0F)
                            .build())));

    public static final RegistryObject<Item> BURGER_EMAS = ITEMS.register("burger_emas",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(10).saturationMod(1.0F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 20 * 20, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 20 * 120, 1), 1.0F)
                            .build())));

    public static final RegistryObject<Item> BURGER_BERLIAN = ITEMS.register("burger_berlian",
            () -> new Item(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(12).saturationMod(1.2F).alwaysEat()
                            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 20 * 30, 2), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 20 * 180, 3), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20 * 180, 1), 1.0F)
                            .effect(() -> new MobEffectInstance(MobEffects.DAMAGE_BOOST, 20 * 120, 1), 1.0F)
                            .build())));

    public static final RegistryObject<Item> BURGER_TELEPORT = ITEMS.register("burger_teleport",
            () -> new TeleportBurgerItem(new Item.Properties().food(
                    new FoodProperties.Builder().nutrition(8).saturationMod(0.8F).alwaysEat().build())));

    // Buku
    public static final RegistryObject<Item> BUKU_RESEP = ITEMS.register("buku_resep",
            () -> new RecipeBookItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("burger_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.burgermod"))
                    .icon(() -> new ItemStack(BURGER_BERLIAN.get()))
                    .displayItems((params, output) ->
                            ITEMS.getEntries().forEach(e -> output.accept(e.get())))
                    .build());
}
