package com.menek.burgermod;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;

/** Burger yang teleport acak (seperti chorus fruit) saat dimakan. */
public class TeleportBurgerItem extends Item {
    public TeleportBurgerItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        if (!level.isClientSide) {
            double ox = entity.getX();
            double oy = entity.getY();
            double oz = entity.getZ();
            int minY = level.getMinBuildHeight();
            int maxY = level.getMaxBuildHeight() - 1;
            for (int i = 0; i < 16; i++) {
                double x = ox + (entity.getRandom().nextDouble() - 0.5D) * 32.0D;
                double y = Mth.clamp(oy + (double) (entity.getRandom().nextInt(16) - 8), minY, maxY);
                double z = oz + (entity.getRandom().nextDouble() - 0.5D) * 32.0D;
                if (entity.isPassenger()) {
                    entity.stopRiding();
                }
                Vec3 before = entity.position();
                if (entity.randomTeleport(x, y, z, true)) {
                    level.gameEvent(GameEvent.TELEPORT, before, GameEvent.Context.of(entity));
                    level.playSound(null, ox, oy, oz, SoundEvents.CHORUS_FRUIT_TELEPORT,
                            SoundSource.PLAYERS, 1.0F, 1.0F);
                    entity.playSound(SoundEvents.CHORUS_FRUIT_TELEPORT, 1.0F, 1.0F);
                    break;
                }
            }
        }
        return result;
    }
}
