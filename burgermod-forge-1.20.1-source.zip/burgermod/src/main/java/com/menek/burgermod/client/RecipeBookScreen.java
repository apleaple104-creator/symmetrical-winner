package com.menek.burgermod.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class RecipeBookScreen extends Screen {
    // {nama, bahan, efek}
    private static final String[][] ENTRIES = {
            {"Roti Burger", "3 Gandum berjejer 1 baris (hasil 2)", "Bahan dasar"},
            {"Patty", "1 Daging Sapi Matang (hasil 2)", "Bahan dasar"},
            {"Burger Biasa", "Roti Burger + Patty + Bit", "Kenyang"},
            {"Burger Api", "Burger Biasa + Blaze Powder", "Tahan Api 3 menit + Kekuatan 30 detik"},
            {"Burger Kecepatan", "Burger Biasa + 2 Gula", "Kecepatan II + Lompat Tinggi II 90 detik"},
            {"Burger Malam", "Burger Biasa + Wortel Emas", "Penglihatan Malam 5 menit"},
            {"Burger Emas", "Burger Biasa + 2 Emas Batangan", "Regenerasi II + Absorpsi II"},
            {"Burger Berlian", "Burger Biasa + 2 Berlian", "Regenerasi III, Absorpsi IV, Resistensi II, Kekuatan II"},
            {"Burger Teleport", "Burger Biasa + Ender Pearl", "Teleport acak sampai 16 blok"},
            {"Buku Resep", "Buku + Burger Biasa", "Klik kanan untuk membuka buku ini"},
    };
    private static final int PER_PAGE = 3;
    private static final int W = 260;
    private static final int H = 200;

    private int page = 0;

    public RecipeBookScreen() {
        super(Component.literal("Buku Resep Burger"));
    }

    private int pages() {
        return (ENTRIES.length + PER_PAGE - 1) / PER_PAGE;
    }

    @Override
    protected void init() {
        int x = (this.width - W) / 2;
        int y = (this.height - H) / 2;
        addRenderableWidget(Button.builder(Component.literal("<"), b -> {
            if (page > 0) page--;
        }).bounds(x + 10, y + H - 26, 30, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> {
            if (page < pages() - 1) page++;
        }).bounds(x + W - 40, y + H - 26, 30, 18).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        int x = (this.width - W) / 2;
        int y = (this.height - H) / 2;

        g.fill(x - 2, y - 2, x + W + 2, y + H + 2, 0xFF5A3A1A);
        g.fill(x, y, x + W, y + H, 0xFFE8CF9A);

        g.drawCenteredString(this.font, this.title, this.width / 2, y + 8, 0xFF3B2410);

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < ENTRIES.length; i++) {
            String[] e = ENTRIES[start + i];
            int ey = y + 26 + i * 50;
            g.drawString(this.font, e[0], x + 12, ey, 0xFF8A2B0B, false);
            g.drawWordWrap(this.font, Component.literal("Bahan: " + e[1]), x + 12, ey + 12, W - 24, 0xFF3B2410);
            g.drawWordWrap(this.font, Component.literal("Efek: " + e[2]), x + 12, ey + 24, W - 24, 0xFF1B5E20);
        }

        g.drawCenteredString(this.font, (page + 1) + " / " + pages(), this.width / 2, y + H - 22, 0xFF3B2410);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
