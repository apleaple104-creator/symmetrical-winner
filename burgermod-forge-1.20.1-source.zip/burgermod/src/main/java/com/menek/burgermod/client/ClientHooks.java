package com.menek.burgermod.client;

import net.minecraft.client.Minecraft;

public class ClientHooks {
    public static void openRecipeBook() {
        Minecraft.getInstance().setScreen(new RecipeBookScreen());
    }
}
